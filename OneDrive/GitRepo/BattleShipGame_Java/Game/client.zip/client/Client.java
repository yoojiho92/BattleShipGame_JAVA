package client;
import Gui.GameBoard;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    private static final String SERVER_IP = "192.168.219.100";
    private static final int SERVER_PORT = 5000;

    public Client(){
        String name = null;
        Scanner scanner = new Scanner(System.in);

        while( true ) {

            System.out.println("게임명을 입력하세요.");
            System.out.print(">>> ");
            name = scanner.nextLine();

            if (name.isEmpty() == false ) {
                break;
            }

            System.out.println("게임명은 한글자 이상 입력해야 합니다.\n");
        }

        scanner.close();

        Socket socket = new Socket();
        try {
            socket.connect( new InetSocketAddress(SERVER_IP, SERVER_PORT) );
            consoleLog("게임에 입장하였습니다.");
            new GameBoard(name,socket);
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
            String request = "join:" + name + "\r\n";
            pw.println(request);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void consoleLog(String log) {
        System.out.println(log);
    }
}